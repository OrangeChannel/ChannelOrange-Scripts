` #!/bin/sh`
` mkdir old`
` chmod +x xdelta3`
` xdelta3 -v -d -s "[ChannelOrange] Watashi ni Tenshi ga Maiorita - 01 (1080p) [599A7351].mkv" "vcdiff/[ChannelOrange] Watashi ni Tenshi ga Maiorita - 01 (1080p) [599A7351].mkv.vcdiff" "[ChannelOrange] Watashi ni Tenshi ga Maiorita - 01 (1080p) [31AC2B6B].mkv"`
` mv "[ChannelOrange] Watashi ni Tenshi ga Maiorita - 01 (1080p) [599A7351].mkv" old`
