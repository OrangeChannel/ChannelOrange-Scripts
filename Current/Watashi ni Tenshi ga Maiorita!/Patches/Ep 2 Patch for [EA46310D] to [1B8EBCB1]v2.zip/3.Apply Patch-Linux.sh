` #!/bin/sh`
` mkdir old`
` chmod +x xdelta3`
` xdelta3 -v -d -s "[ChannelOrange] Watashi ni Tenshi ga Maiorita - 02 (1080) [EA46310D].mkv" "vcdiff/[ChannelOrange] Watashi ni Tenshi ga Maiorita - 02 (1080) [EA46310D].mkv.vcdiff" "[ChannelOrange] Watashi ni Tenshi ga Maiorita - 02 (1080p) [1B8EBCB1]v2.mkv"`
` mv "[ChannelOrange] Watashi ni Tenshi ga Maiorita - 02 (1080) [EA46310D].mkv" old`
