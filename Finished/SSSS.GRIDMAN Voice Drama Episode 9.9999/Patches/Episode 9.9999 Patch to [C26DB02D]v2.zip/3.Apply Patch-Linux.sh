` #!/bin/sh`
` mkdir old`
` chmod +x xdelta3`
` xdelta3 -v -d -s "[ChannelOrange] SSSS.GRIDMAN Voice Drama - 9.9999 (OPUS).mkv" "vcdiff/[ChannelOrange] SSSS.GRIDMAN Voice Drama - 9.9999 (OPUS).mkv.vcdiff" "[ChannelOrange] SSSS.GRIDMAN Voice Drama - 9.9999 (OPUS) [C26DB02D]v2.mkv"`
` mv "[ChannelOrange] SSSS.GRIDMAN Voice Drama - 9.9999 (OPUS).mkv" old`
